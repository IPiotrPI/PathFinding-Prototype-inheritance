﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using PongEx1.BlindShop.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    class SceneManager:ISceneManager
    {
        
        public List<IEntity> EntityList;
        public List<AIComponentManager> MindsList;
        public List<IEntity> _updatable;
        public SpriteBatch spriteBatch;
      

        public SceneManager()
        {
            EntityList = new List<IEntity>();
            _updatable = new List<IEntity>();
            MindsList = new List<AIComponentManager>();
        }
        
        public void addEntity(IEntity entity)
        {   //add entities to List
            EntityList.Add(entity);
            
        }

        public void AddMind(AIComponentManager mind)
        {
            MindsList.Add(mind);
        }

        public void AddUpdatable(IEntity updatable)
        {
            _updatable.Add(updatable);
        }
        public void removeEntity(IEntity entity)
        {   //add entities to List
            EntityList.Remove(entity);

        }

        public void RemoveUpdatable(IEntity item)
        {
            _updatable.Remove(item);
        }

        public void removeBody(AIComponentManager mind)
        {
            MindsList.Remove(mind);
        }
        public void Draw()
        {
            //draw
            foreach (IEntity entity in EntityList)
            {
                entity.draw(spriteBatch);
            }
  
        }
       
        public void Update(GameTime gameTime)
        {
           //update
         //   for (int i = 0; i < _updatable.Count; i++)
         //   {
                for (int j = 0; j < MindsList.Count; j++)
                {
                    _updatable[j].Update(MindsList[j], gameTime);                 
                }

           // }

        }

    }
}
