﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    class StateMachine : IStateMachine
    {

        public Dictionary<string, IState> AvaibleStates;


        public delegate void UpdateStateDelegate(IAIUser _entityBody);
        //
        public IState _current_state;



        public StateMachine()
        {
            AvaibleStates = new Dictionary<string, IState>();
        }
        public void AddToCollection(string name, IState _state)
        {
            AvaibleStates.Add(name, _state);
        }

        /*public void TransitionTo(string _state)
        {
            Console.WriteLine("CHANGING STATE TO: " + _state);
            _current_state = AvaibleStates[_state];
        }*/

        public IState ReturnCurrentState()
        {
            
            return _current_state;
        }

        public void SetCurrentState(string name)
        {
            _current_state = AvaibleStates[name];
        }

        public void Change(string _name, params Object[] args)
        {
            if (_current_state == null)
            {
               
                IState _next = AvaibleStates[_name];
                _current_state.Enter(args);
                _current_state = _next;
            }
            else if (AvaibleStates.TryGetValue(_name, out IState state) == false)
            {
                state = _current_state;
            }
            else
            {
                _current_state.Exit();
                IState _next = AvaibleStates[_name];
                _current_state.Enter(args);
                _current_state = _next;
            }
        }

        public void update(IAIUser entity)
        {
            
            _current_state.Update(entity);
        }

        public void HandleInput(IAIUser _collidedWith)
        {
            _current_state.HandleInput(_collidedWith);
        }
    }
}
