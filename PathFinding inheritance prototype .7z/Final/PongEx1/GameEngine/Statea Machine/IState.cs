﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
   public interface IState
    {
        void Update(IAIUser _entityBody);
        void HandleInput(IAIUser _collidedWith);

        void Enter(params object[] args);
        void Exit();
    }
}
