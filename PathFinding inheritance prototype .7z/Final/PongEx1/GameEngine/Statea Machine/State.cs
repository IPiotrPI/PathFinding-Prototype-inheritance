﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
   abstract class State : IState
    {
        protected string _context;

        public void SetContext(string _NectContext)
        {
            _context = _NectContext;
        }

        public string GetContext()
        {
            return _context;
        }

        public abstract void Update(IAIUser _entityBody);

        public abstract void HandleInput(IAIUser _collidedWith);

        public abstract void Enter(params object[] args);


        public abstract void Exit();

    }
}
