﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    public interface IStateMachine
    {

        IState ReturnCurrentState();

        void Change(string _name, params Object[] args);

        void HandleInput(IAIUser _collidedWith);

        void AddToCollection(string name, IState _state);

        void SetCurrentState(string name);

        void update(IAIUser entity);
    }
}
