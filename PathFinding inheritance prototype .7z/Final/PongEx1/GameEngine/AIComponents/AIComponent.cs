﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    abstract class AIComponent : AIComponentManager
    {


        public abstract void onCollide(IAIUser _entity);

        public delegate void updateDelegate(IAIUser _entity);
        public abstract IStateMachine ReturnStateMachine();

        public abstract IAIUser ReturnBody();

        public bool AmIMoving(IAIUser _entity)
        {
            if (_entity.GetVelocity() != Vector2.Zero)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        



    }
}
