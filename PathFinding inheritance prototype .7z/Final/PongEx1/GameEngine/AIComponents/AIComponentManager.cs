﻿namespace PongEx1
{
    public interface AIComponentManager
    {
    }
}
