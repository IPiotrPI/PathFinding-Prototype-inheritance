﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
   public  interface IAIUser
    {

        Vector2 GetEntityLocn();

        Texture2D GetTexture();

        void SetTexture(bool IsSomeoneThere);

        void setVelocity(Vector2 _velocity);

        void SetVelocityX(float X);
        void SetVelocityY(float Y);

        void setEntitylocnX(float entlcnX);

        void setEntitylocnY(float entlcnY);

        Vector2 GetVelocity();

        void setEntitylocnUpdate(Vector2 entlcn);


    }
}
