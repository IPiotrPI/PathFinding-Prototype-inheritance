﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    interface IInputListener
    {
        void setVelocity(Vector2 velocity, IAIUser entity);
    }
}
