﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PongEx1
{
    class CollisionManager:ICollisionManager, ICollisionSubscriber
    {

        private List<ICollidable> EntityList;
        private List<IAIUser> BodyList;

        public CollisionManager()
        {
            EntityList = new List<ICollidable>();
            BodyList = new List<IAIUser>();
        }

        
        public void CollideCheck()
        {
            //if paddle and ball collide, then return true
            for(int i=0;i<EntityList.Count-1;i++)
            {
                for(int j=i+1;j<EntityList.Count;j++)
                {
                    if (EntityList[i].getHitBox(BodyList.ElementAt(i)).Intersects(EntityList[j].getHitBox(BodyList.ElementAt(j))))
                    {
                        EntityList[i].onCollide(BodyList[i],BodyList[j]);
                        EntityList[j].onCollide(BodyList[j],BodyList[i]);
                    }
                }
                
            }
        }

        public void Subscribe(ICollidable collidable)
        {
            EntityList.Add(collidable);
        }

        public void SubscribeBody(IAIUser body)
        {
            BodyList.Add(body);
        }

        public void Unsubscribe(ICollidable collidable)
        {
            EntityList.Remove(collidable);
        }

        public void UnsubscribeBody(IAIUser body)
        {
            BodyList.Remove(body);
        }

        public void Update() {
            CollideCheck();
            
        }
    }
}
