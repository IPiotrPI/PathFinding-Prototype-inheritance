﻿using Microsoft.Xna.Framework;
using PongEx1.BlindShop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    class EntityManager:IEntityManager
    {
        ISceneManager sceneManager;
        //Creates a IEntity object with a dynamic type of ball.
        public IEntity createTileFloor(int id, Vector2 location)
        {
            IEntity Tile = new FloorTile(id, location);

            return Tile;
        }
        //Terminate an entity from the game world
        public void Terminate(IEntity entity, ISceneManager pSceneManager)
        {
            sceneManager = pSceneManager;
            sceneManager.removeEntity(entity);

            }
        }
}
