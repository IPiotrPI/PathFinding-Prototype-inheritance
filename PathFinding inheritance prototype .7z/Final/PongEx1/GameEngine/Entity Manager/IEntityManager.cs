﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1
{
    interface IEntityManager
    {
        IEntity createTileFloor(int id, Vector2 location);
        void Terminate(IEntity entity, ISceneManager sceneManager);
    }
}
