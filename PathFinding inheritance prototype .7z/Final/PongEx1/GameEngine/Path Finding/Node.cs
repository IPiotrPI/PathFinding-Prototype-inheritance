﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.GameEngine.Path_Finding
{
    class Node : INode
    {
        private Vector2 _nodelcn;
        private int id;
        private float G; //From start to this
        private float H; //From this to goal
        private float F = 1; // sum of G and H to estimate how if we should go trhough this node to goal. The lower the better
        private INode _parent;

        public Node(int _id, Vector2 NodeLocation)
        {
            id = _id;
            _nodelcn = NodeLocation;
        }

       public void setG(float g)
        {
            G += g;
        }

        public float getG()
        {
            return G;
        }
        public void setH(Vector2 _goalX, Vector2 _goalY)
        {

            H = Math.Abs(_goalX.X - _goalY.X) + Math.Abs(_goalX.Y - _goalY.Y);
        }
        public float getH()
        {
            return H;
        }

        public void SetPArent(INode _newParent)
        {
            _parent = _newParent;
        }
        public INode GetParent()
        {
            return _parent;
        }

        public float CalculateF()
        {
            F = G + H;
            return F;
        }

        public float GetF()
        {
            return F;
        }

        public Vector2 GetLocaction()
        {
            return _nodelcn;
        }

        public int GetID()
        {
            return id;
        }

    }
}
