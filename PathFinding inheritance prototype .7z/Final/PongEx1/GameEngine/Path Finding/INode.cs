﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.GameEngine.Path_Finding
{
    interface INode
    {
        void setG(float g);

        float getG();

        void setH(Vector2 _goalX, Vector2 _goalY);

        float getH();

        float CalculateF();

        float GetF();

        void SetPArent(INode _newParent);
        INode GetParent();

        Vector2 GetLocaction();

        int GetID();
    }
}
