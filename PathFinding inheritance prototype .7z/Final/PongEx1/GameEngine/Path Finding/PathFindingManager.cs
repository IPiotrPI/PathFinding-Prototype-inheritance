﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.GameEngine.Path_Finding
{
    class PathFindingManager : IPathfinderManager
    {

        public Dictionary<int, INode> OpenNodes;
        public Dictionary<int, INode> CloseNodes;


        private int Open_id = 0;


        private int spaceXbetweenNodes;
        private int spaceYbetweenNodes;

        public PathFindingManager()
        {
            OpenNodes = new Dictionary<int, INode>();
            CloseNodes = new Dictionary<int, INode>();
            //SearchThrueTheMap(2,15);
            //path(2, 6);
        }

        public void InitializeTheGrid(int HeightoftheScreenInGame, int WidthoftheScreenInGame)
        {
            spaceXbetweenNodes = WidthoftheScreenInGame / 5;
            spaceYbetweenNodes = HeightoftheScreenInGame / 5;
            //Console.WriteLine(spaceXbetweenNodes);
            //Console.WriteLine(spaceYbetweenNodes);

            for (int Y = 0; Y <= HeightoftheScreenInGame; Y += spaceYbetweenNodes)
            {
                for (int X = 0; X <= WidthoftheScreenInGame; X += spaceXbetweenNodes)
                {
                    INode _node = new Node(Open_id, new Vector2(X, Y));
                    OpenNodes.Add(Open_id, _node);
                    Open_id++;
                }
            }
        }

        public void AddToOpen(int id ,INode _node)
        {
            OpenNodes.Add(id, _node);
        }

        public Dictionary<int, INode> GetOpen()
        {
            return OpenNodes;
        }

        public void RemoveFromOpen(int id)
        {
            OpenNodes.Remove(id);
        }

        public INode GetNode(int id)
        {
            return OpenNodes[id];
        }

        public float CalculateHeuristic(Vector2 _goalX, Vector2 _goalY)
        {
            return Math.Abs(_goalX.X - _goalY.X) + Math.Abs(_goalX.Y - _goalY.Y);
        }

        public Dictionary<int, INode> path(INode _goal)
        {
            Dictionary<int, INode> path = new Dictionary<int, INode>();
            if(_goal.GetParent() != null)
            {
                path.Add(_goal.GetID(), _goal);
                _goal = _goal.GetParent();
                Console.WriteLine(_goal.GetID() + " " + _goal.GetLocaction());
            }
            return path;

        }         
        public Queue<INode> SearchThrueTheMap(int _startID, int _goalID)
        {
            //LIST of nodes on the front of the search
            Queue<INode> _frontier = new Queue<INode>();
            //List of nodes that we have seen
            Dictionary<int, INode> came_from = new Dictionary<int, INode>();
            //Nodes that we think are correct path
            Queue<INode> _path = new Queue<INode>();

            //Add starting point to the _frontier
            _frontier.Enqueue(OpenNodes[_startID]);
            //Add starting point to path
            _path.Enqueue(OpenNodes[_startID]);

            //when _frontier is not empty
            while (_frontier.Count > 0)
            {
                //take out a node from the queue
                INode _current = _frontier.Dequeue();
                //Set Current G, H and F
                _current.setG(_current.getG() + 10f);
                _current.setH(_current.GetLocaction(), OpenNodes[_goalID].GetLocaction());
                _current.CalculateF();
                //Console.WriteLine(_current.GetID() + " " + _current.getH() + " " + _current.GetF() + " " + _current.getG());
                    //if we have been there
                    if (came_from.ContainsKey(_current.GetID()))
                    {
                        // dont do anything
                        continue ;
                    }
                    else          
                    //Add node to the seen nodes
                    came_from.Add(_current.GetID(), _current);
                    {
                            //For each node in the set of neighbours
                            foreach (INode item in FindNeighbours(_current.GetID()))
                            {
                                //set neighbours G, H and F
                                item.setG(_current.getG() + 10f);
                                item.setH(item.GetLocaction(), OpenNodes[_goalID].GetLocaction());
                                item.CalculateF();
                                // IF value F is smaller or equal to the current node, and path does not already contain this node
                                if (item.GetF() <=  _current.GetF() && _path.Contains(item) == false) 
                                {        
                                //Add item to the frontier
                                  _frontier.Enqueue(item);
                                //Add item to the path
                                 _path.Enqueue(item);
                              Console.WriteLine(_path.Count + " " + item.GetID());
                                //IF path contain the goalID break the loop and supposedly create the path (does not work)
                                if(_path.Contains(OpenNodes[_goalID]) == true)
                                {
                                     path(OpenNodes[_goalID]);
                                    break;
                                }
                                }
                                else
                                {
                                    continue;
                                }
                            }                       
                    }             
            }           
            return _path;           
        }

    


        public List<INode> FindNeighbours(int id)
        {
            //create list of neighbours 
            List<INode> _listOfNeighbours = new List<INode>(8);

            //Add neighbour to the list if neighbour is not null
            if (GetLeft(id) != null) { _listOfNeighbours.Add(GetLeft(id));}
            if (GetRight(id) != null) { _listOfNeighbours.Add(GetRight(id)); }
            if (GetUp(id) != null) { _listOfNeighbours.Add(GetUp(id)); }
            if (GetDown(id) != null) { _listOfNeighbours.Add(GetDown(id)); }
            //After writing my documentation I tried one more thing to resolve my problem. That did not work as well...
            if (GetUPLeft(id) != null) { _listOfNeighbours.Add(GetUPLeft(id)); }
            if (GetUPRight(id) != null) { _listOfNeighbours.Add(GetUPRight(id)); }
            if (GetDOWNLeft(id) != null) { _listOfNeighbours.Add(GetDOWNLeft(id)); }
            if (GetDOWNRight(id) != null) { _listOfNeighbours.Add(GetDOWNRight(id)); }

            return _listOfNeighbours;
        }

        public INode GetRight(int id)
        {

            if (id+1 < OpenNodes.Count && (id+1) / 6 <= 1 && OpenNodes.ContainsKey(id + 1) == true) 
            {
                INode right = OpenNodes[id + 1];

                //Console.WriteLine(right.GetID() + " " + right.getH() + " " + right.GetF() + " " + right.getG());
                return right;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }
        public INode GetUPRight(int id)
        {

            if (id -5 > 0)
            {
                INode Upright = OpenNodes[id - 5];

                //Console.WriteLine(right.GetID() + " " + right.getH() + " " + right.GetF() + " " + right.getG());
                return Upright;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }

        public INode GetDOWNRight(int id)
        {

            if (id + 7 <= OpenNodes.Count && OpenNodes.ContainsKey(id + 7) == true)
            {
                INode DOWNright = OpenNodes[id + 7];

                //Console.WriteLine(right.GetID() + " " + right.getH() + " " + right.GetF() + " " + right.getG());
                return DOWNright;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }


        public INode GetLeft(int id)
        {

            
            if (id-1 > 0 && (id - 1) / 6 <= 1)
            {
                INode left = OpenNodes[id - 1];
                //Console.WriteLine(left.GetID() + " " + left.getH() + " " + left.GetF() + " " + left.getG());
                return left;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }

        public INode GetUPLeft(int id)
        {

            if (id - 7 > 0)
            {
                INode UPleft = OpenNodes[id - 7];

                //Console.WriteLine(right.GetID() + " " + right.getH() + " " + right.GetF() + " " + right.getG());
                return UPleft;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }

        public INode GetDOWNLeft(int id)
        {

            if (id + 5 <= OpenNodes.Count && OpenNodes.ContainsKey(id + 5) == true)
            {
                INode DOWNleft = OpenNodes[id + 5];

                //Console.WriteLine(right.GetID() + " " + right.getH() + " " + right.GetF() + " " + right.getG());
                return DOWNleft;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }

        public INode GetUp(int id)
        {
            if (id-6 > 0)
            {
                INode up = OpenNodes[id - 6];
                //Console.WriteLine(up.GetID() + " " + up.getH() + " " + up.GetF() + " " + up.getG());
                return up;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }

        public INode GetDown(int id)
        {
            if (id+6 < OpenNodes.Count && OpenNodes.ContainsKey(id + 6) == true)
            {
                INode down = OpenNodes[id + 6];
                //Console.WriteLine(down.GetID() + " " + down.getH() + " " + down.GetF() + " " + down.getG());
                return down;
            }
            else
            {
                //Console.WriteLine("there is no such node");
                return null;
            }
        }

    }
}
