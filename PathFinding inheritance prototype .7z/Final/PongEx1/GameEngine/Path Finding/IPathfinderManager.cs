﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PongEx1.GameEngine.Path_Finding
{
    interface IPathfinderManager
    {
        void AddToOpen(int id, INode _node);

        void RemoveFromOpen(int id);

        void InitializeTheGrid(int HeightoftheScreen, int WidthoftheScreen);

        List<INode> FindNeighbours(int id);
        Queue<INode> SearchThrueTheMap(int _startID, int _goalID);

        Dictionary<int, INode> GetOpen();

        INode GetNode(int id);
    }
}
