﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System;
using PongEx1.GameEngine.Path_Finding;
using PongEx1.BlindShop;
using PongEx1.BlindShop.BlindShopAIComponents;
using PongEx1.BlindShop.Entities;

namespace PongEx1
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Kernel : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //DECLARE: Screen Size
        public static int ScreenWidth;
        public static int ScreenHeight;
        //DECLARE Managers
        SceneManager sceneManager;
        IEntityManager entityManager;
        private ICollisionManager collisionManager;
        //DECLARE Entitys
       // private IfloorAI Map;
        private IEntity Tile1;
        private IEntity Tile2;
        private IEntity Tile3;
        private IEntity Tile4;
        private IEntity Tile5;
        private IEntity Tile6;
        private IEntity Tile7;
        private IEntity Tile8;
        private IEntity Tile9;
        private IEntity Tile10;
        private IEntity Tile11;
        private IEntity Shelve1;
        private IEntity Tile13;
        private IEntity Tile14;
        private IEntity Tile15;
        private IEntity Tile16;
        private IEntity Tile17;
        private IEntity Shelve2;
        private IEntity Tile19;
        private IEntity Tile20;
        private IEntity Tile21;
        private IEntity Tile22;
        private IEntity Tile23;
        private IEntity Shelve3;
        private IEntity Tile25;
        private IEntity Tile26;
        private IEntity Tile27;
        private IEntity Tile28;
        private IEntity Tile29;
        private IEntity Shelve4;
        private IEntity Tile31;
        private IEntity Tile32;
        private IEntity Tile33;
        private IEntity Tile34;
        private IEntity Tile35;
        private IEntity Tile36;
        private AIComponentManager Neighbour1;
        private AIComponentManager Neighbour2;
        private AIComponentManager Neighbour3;
        private AIComponentManager Neighbour4;
        private AIComponentManager Neighbour5;
        private AIComponentManager Neighbour6;
        private AIComponentManager Finish1;
        private AIComponentManager DroneDock;

        private AIComponentManager _customerAI;
        private IEntity _customer;

        private AIComponentManager _droneAI;
        private IEntity _drone;


        //*************************************PATH FINDING TEST*********************************//
        private IPathfinderManager _node_grid;
        private Dictionary<int, IKindOfFloor> Map;

        //DECLARE Input
        private KeyboardState _oldState;

        public Kernel()
        {
            //INITIATE: Graphic manager
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferHeight = 900;
            graphics.PreferredBackBufferWidth = 1600;
            Content.RootDirectory = "Content";                   
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            ScreenHeight = GraphicsDevice.Viewport.Height;
            ScreenWidth = GraphicsDevice.Viewport.Width;
            //initialise SceneManager
            sceneManager = new SceneManager();
            //initialise EntityManager
            entityManager = new EntityManager();
            spriteBatch = new SpriteBatch(GraphicsDevice);
            sceneManager = new SceneManager();
            collisionManager = new CollisionManager();
            _node_grid = new PathFindingManager();
            Map = new Dictionary<int, IKindOfFloor>();

            Shelve1 = new Shelve(new Vector2(160, 32), Content.Load<Texture2D>("Shelve"), Content.Load<Texture2D>("EmptyShelve"));
            Shelve2 = new Shelve(new Vector2(160, 64), Content.Load<Texture2D>("Shelve"), Content.Load<Texture2D>("EmptyShelve"));
            Shelve3 = new Shelve(new Vector2(160, 96), Content.Load<Texture2D>("Shelve"), Content.Load<Texture2D>("EmptyShelve"));
            Shelve4 = new Shelve(new Vector2(160, 128), Content.Load<Texture2D>("Shelve"), Content.Load<Texture2D>("EmptyShelve"));


            Tile1 = new FloorTile(1, new Vector2(0, 0));
            ((IKindOfFloor)Tile1).SetAmIStart(true);
            _node_grid.AddToOpen(1, ((IKindOfFloor)Tile1).GetNode());
            Map.Add(1, (IKindOfFloor)Tile1);

            Tile2 = new FloorTile(2, new Vector2(32, 0));
            _node_grid.AddToOpen(2, ((IKindOfFloor)Tile2).GetNode());
            Map.Add(2, (IKindOfFloor)Tile2);

            Tile3 = new FloorTile(3, new Vector2(64, 0));
            _node_grid.AddToOpen(3, ((IKindOfFloor)Tile3).GetNode());
            Map.Add(3, (IKindOfFloor)Tile3);

            Tile4 = new FloorTile(4, new Vector2(96, 0));
            _node_grid.AddToOpen(4, ((IKindOfFloor)Tile4).GetNode());
            Map.Add(4, (IKindOfFloor)Tile4);

            Tile5 = new FloorTile(5, new Vector2(128, 0));
            _node_grid.AddToOpen(5, ((IKindOfFloor)Tile5).GetNode());
            Map.Add(5, (IKindOfFloor)Tile5);

            Tile6 = new FloorTile(6, new Vector2(160, 0));
            ((IKindOfFloor)Tile6).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(6, ((IKindOfFloor)Tile6).GetNode());
            Map.Add(6, (IKindOfFloor)Tile6);
            Neighbour3 = new FloorAI(Tile6 as IAIUser, Shelve2 as IAIUser);

            Tile7 = new FloorTile(7, new Vector2(0, 32));
            _node_grid.AddToOpen(7, ((IKindOfFloor)Tile7).GetNode());
            Map.Add(7, (IKindOfFloor)Tile7);

            Tile8 = new FloorTile(8, new Vector2(32, 32));
            _node_grid.AddToOpen(8, ((IKindOfFloor)Tile8).GetNode());
            Map.Add(8, (IKindOfFloor)Tile8);
            

            Tile9 = new FloorTile(9, new Vector2(64, 32));
            _node_grid.AddToOpen(9, ((IKindOfFloor)Tile9).GetNode());
            Map.Add(9, (IKindOfFloor)Tile9);

            Tile10 = new FloorTile(10, new Vector2(96, 32));
            _node_grid.AddToOpen(10, ((IKindOfFloor)Tile10).GetNode());
            Map.Add(10, (IKindOfFloor)Tile10);

            Tile11 = new FloorTile(11, new Vector2(128, 32));
            ((IKindOfFloor)Tile11).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(11, ((IKindOfFloor)Tile11).GetNode());
            Map.Add(11, (IKindOfFloor)Tile11);
            Neighbour1 = new FloorAI(Tile11 as IAIUser, Shelve3 as IAIUser);
            
            

            Tile13 = new FloorTile(13, new Vector2(0, 64));
            ((IKindOfFloor)Tile13).SetAmIFinish(true);
            _node_grid.AddToOpen(13, ((IKindOfFloor)Tile13).GetNode());
            Map.Add(13, (IKindOfFloor)Tile13);
            

            Tile14 = new FloorTile(14, new Vector2(32, 64));
            ((IKindOfFloor)Tile14).SetAmIFinish(true);
            _node_grid.AddToOpen(14, ((IKindOfFloor)Tile14).GetNode());
            Map.Add(14, (IKindOfFloor)Tile14);
            Console.WriteLine(Tile14.id);
            Finish1 = new FloorAI(Tile14 as IAIUser);


            Tile15 = new FloorTile(15, new Vector2(64, 64));
            ((IKindOfFloor)Tile15).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(15, ((IKindOfFloor)Tile15).GetNode());
            Map.Add(15, (IKindOfFloor)Tile15);


            Tile16 = new FloorTile(16, new Vector2(96, 64));
            _node_grid.AddToOpen(16, ((IKindOfFloor)Tile16).GetNode());
            Map.Add(16, (IKindOfFloor)Tile16);

            Tile17 = new FloorTile(17, new Vector2(128, 64));
            ((IKindOfFloor)Tile17).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(17, ((IKindOfFloor)Tile17).GetNode());
            Map.Add(17, (IKindOfFloor)Tile17);
            Neighbour2 = new FloorAI(Tile17 as IAIUser, Shelve1 as IAIUser);

            

            Tile19 = new FloorTile(19, new Vector2(0, 96));
            _node_grid.AddToOpen(19, ((IKindOfFloor)Tile19).GetNode());
            Map.Add(19, (IKindOfFloor)Tile19);

            Tile20 = new FloorTile(20, new Vector2(32, 96));
            _node_grid.AddToOpen(20, ((IKindOfFloor)Tile20).GetNode());
            Map.Add(20, (IKindOfFloor)Tile20);

            Tile21 = new FloorTile(21, new Vector2(64, 96));
            _node_grid.AddToOpen(21, ((IKindOfFloor)Tile21).GetNode());
            Map.Add(21, (IKindOfFloor)Tile21);

            Tile22 = new FloorTile(22, new Vector2(96, 96));
            _node_grid.AddToOpen(22, ((IKindOfFloor)Tile22).GetNode());
            Map.Add(22, (IKindOfFloor)Tile22);

            Tile23 = new FloorTile(23, new Vector2(128, 96));
            ((IKindOfFloor)Tile23).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(23, ((IKindOfFloor)Tile23).GetNode());
            Map.Add(23, (IKindOfFloor)Tile23);
            Neighbour4 = new FloorAI(Tile23 as IAIUser, Shelve3 as IAIUser);

            

            Tile25 = new FloorTile(25, new Vector2(0, 128));
            _node_grid.AddToOpen(25, ((IKindOfFloor)Tile25).GetNode());
            Map.Add(25, (IKindOfFloor)Tile25);

            Tile26 = new FloorTile(26, new Vector2(32, 128));
            _node_grid.AddToOpen(26, ((IKindOfFloor)Tile26).GetNode());
            Map.Add(26, (IKindOfFloor)Tile26);

            Tile27 = new FloorTile(27, new Vector2(64, 128));
            _node_grid.AddToOpen(27, ((IKindOfFloor)Tile27).GetNode());
            Map.Add(27, (IKindOfFloor)Tile27);

            Tile28 = new FloorTile(28, new Vector2(96, 128));
            _node_grid.AddToOpen(28, ((IKindOfFloor)Tile28).GetNode());
            Map.Add(28, (IKindOfFloor)Tile28);

            Tile29 = new FloorTile(29, new Vector2(128, 128));
            ((IKindOfFloor)Tile29).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(29, ((IKindOfFloor)Tile29).GetNode());
            Map.Add(29, (IKindOfFloor)Tile29);
            Neighbour5 = new FloorAI(Tile29 as IAIUser, Shelve4 as IAIUser);

            

            Tile31 = new FloorTile(31, new Vector2(0, 160));
            _node_grid.AddToOpen(31, ((IKindOfFloor)Tile31).GetNode());
            Map.Add(31, (IKindOfFloor)Tile31);

            Tile32 = new FloorTile(32, new Vector2(32, 160));
            _node_grid.AddToOpen(32, ((IKindOfFloor)Tile32).GetNode());
            Map.Add(32, (IKindOfFloor)Tile32);

            Tile33 = new FloorTile(33, new Vector2(64, 160));
            _node_grid.AddToOpen(33, ((IKindOfFloor)Tile33).GetNode());
            Map.Add(33, (IKindOfFloor)Tile33);

            Tile34 = new FloorTile(34, new Vector2(96, 160));
            _node_grid.AddToOpen(34, ((IKindOfFloor)Tile34).GetNode());
            ((IKindOfFloor)Tile34).SetAmIDock(true);
            Map.Add(34, (IKindOfFloor)Tile34);
            DroneDock = new FloorAI(Tile34 as IAIUser);


            Tile35 = new FloorTile(35, new Vector2(128, 160));
            _node_grid.AddToOpen(35, ((IKindOfFloor)Tile35).GetNode());
            Map.Add(35, (IKindOfFloor)Tile35);

            Tile36 = new FloorTile(36, new Vector2(160, 160));
            ((IKindOfFloor)Tile36).SetAmIAroundSelve(true);
            _node_grid.AddToOpen(36, ((IKindOfFloor)Tile36).GetNode());
            Map.Add(36, (IKindOfFloor)Tile36);
            Neighbour6 = new FloorAI(Tile36 as IAIUser, Shelve4 as IAIUser);

            _customer = new Customer(Map);
            _customer.setPosition(0, 0);
            _customerAI = new CustomerAI(_customer as IAIUser);

            _drone = new RestockDrone();
            _drone.setPosition(96, 128);
            _droneAI = new DroneAI(_drone as IAIUser);


    

            sceneManager.addEntity(Tile1);
            sceneManager.addEntity(Tile2);
            sceneManager.addEntity(Tile3);
            sceneManager.addEntity(Tile4);
            sceneManager.addEntity(Tile5);
            sceneManager.addEntity(Tile6);
            sceneManager.addEntity(Tile7);
            sceneManager.addEntity(Tile8);
            sceneManager.addEntity(Tile9);
            sceneManager.addEntity(Tile10);
            sceneManager.addEntity(Tile11);
            sceneManager.addEntity(Shelve1);
            sceneManager.addEntity(Tile13);
            sceneManager.addEntity(Tile14);
            sceneManager.addEntity(Tile15);
            sceneManager.addEntity(Tile16);
            sceneManager.addEntity(Tile17);
            sceneManager.addEntity(Shelve2);
            sceneManager.addEntity(Tile19);
            sceneManager.addEntity(Tile20);
            sceneManager.addEntity(Tile21);
            sceneManager.addEntity(Tile22);
            sceneManager.addEntity(Tile23);
            sceneManager.addEntity(Shelve3);
            sceneManager.addEntity(Tile25);
            sceneManager.addEntity(Tile26);
            sceneManager.addEntity(Tile27);
            sceneManager.addEntity(Tile28);
            sceneManager.addEntity(Tile29);
            sceneManager.addEntity(Shelve4);
            sceneManager.addEntity(Tile31);
            sceneManager.addEntity(Tile32);
            sceneManager.addEntity(Tile33);
            sceneManager.addEntity(Tile34);
            sceneManager.addEntity(Tile35);
            sceneManager.addEntity(Tile36);
            sceneManager.addEntity(_customer);
            sceneManager.AddUpdatable(_customer);
            sceneManager.AddMind(_customerAI);

            

            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)_droneAI);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(_drone as IAIUser);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Neighbour1);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Neighbour2);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Neighbour3);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Neighbour4);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Neighbour5);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Neighbour6);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)Finish1);
            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)DroneDock);

            //SUBSCRIBE: entities to the array of bodies
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile6 as IAIUser);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile11 as IAIUser);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile17 as IAIUser);

            //SUBSCRIBE: entities to the array of bodies
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile23 as IAIUser);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile29 as IAIUser);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile36 as IAIUser);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile14 as IAIUser);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(Tile34 as IAIUser);

            ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)_customerAI);
            ((ICollisionSubscriber)collisionManager).SubscribeBody(_customer as IAIUser);

            




            sceneManager.spriteBatch = spriteBatch;



            //add entities to list





            //***************************************PATH FINDING TEST**********************//

            //_node_grid.FindNeighbours(15);
            //_node_grid.SearchThrueTheMap(1,15);


            //INPUT
            _oldState = Keyboard.GetState();



            base.Initialize();
            
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {        
            Tile1.setTexture(Content.Load<Texture2D>("StartTile"));
            Tile2.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile3.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile4.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile5.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile6.setTexture(Content.Load<Texture2D>("AroundShelve"));
            Tile7.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile8.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile9.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile10.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile11.setTexture(Content.Load<Texture2D>("AroundShelve"));
            Shelve1.setTexture(Content.Load<Texture2D>("Shelve"));
            Tile13.setTexture(Content.Load<Texture2D>("FinishTile"));
            Tile14.setTexture(Content.Load<Texture2D>("FinishTile"));
            Tile15.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile16.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile17.setTexture(Content.Load<Texture2D>("AroundShelve"));
            Shelve2.setTexture(Content.Load<Texture2D>("Shelve"));
            Tile19.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile20.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile21.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile22.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile23.setTexture(Content.Load<Texture2D>("AroundShelve"));
            Shelve3.setTexture(Content.Load<Texture2D>("Shelve"));
            Tile25.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile26.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile27.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile28.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile29.setTexture(Content.Load<Texture2D>("AroundShelve"));
            Shelve4.setTexture(Content.Load<Texture2D>("Shelve"));
            Tile31.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile32.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile33.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile34.setTexture(Content.Load<Texture2D>("DroneDock"));
            Tile35.setTexture(Content.Load<Texture2D>("FloorTile"));
            Tile36.setTexture(Content.Load<Texture2D>("AroundShelve"));
            _customer.setTexture(Content.Load<Texture2D>("Walker"));
            Content.Load<Texture2D>("RestockDrone");
            
        }

        
        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
            base.UnloadContent();
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            sceneManager.Draw();
            spriteBatch.End();
            base.Draw(gameTime);
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            

            ScreenHeight = GraphicsDevice.Viewport.Height;
            ScreenWidth = GraphicsDevice.Viewport.Width;

            
      
          
            if(((IAIUser)_customer).GetTexture() == null && sceneManager.EntityList.Contains(_drone) == false)
            {
                ((IAIUser)_drone).setVelocity(new Vector2(2, 2));
                sceneManager.addEntity(_drone);
                sceneManager.AddUpdatable(_drone);
                sceneManager.AddMind(_droneAI);
                _drone.setTexture(Content.Load<Texture2D>("RestockDrone"));
                /*ball2 = entityManager.createBall();
                ball2.setTexture(Content.Load<Texture2D>("square"));
                sceneManager.addEntity(ball2);
                ((ICollisionSubscriber)collisionManager).Subscribe((ICollidable)ball2);
                ball2.Initialise();
                Console.WriteLine("SPACE");*/


            }
            collisionManager.Update();
            sceneManager.Update(gameTime);
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
     
    }
}
